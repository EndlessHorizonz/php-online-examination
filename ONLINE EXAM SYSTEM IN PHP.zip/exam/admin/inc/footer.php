 </section>
<section class="footeroption">
		<h2 style="font-size: 15px" >  <?php echo "Copyright:Mvurwi High School www.mvurwihigh.ac.zw 2021"; ?></h2>
	</section>
</div>
</body>
</html>