<?php include 'inc/header.php'; ?>
<?php
Session::checkLogin();
?>
<style >
	.btn-primary {
  color: #fff;
  background-color: #007bff;
  border-color: #007bff;
}
</style>

<div  class="main">
<h1 style="color: #343a40;"> Online Exam System - Student Login</h1>
	<div class="segment" style="margin-right:30px;">
		<img src="img/test.png"/>
	</div>
	<div  class="segment">
	<form action="" method="post" >
		<table style="font-size: 20px;"  class="tbl">    
			 <tr>
			   <td>Email</td>
			   <td><input   autocomplete="off" name="email" type="text" id="email"></td>

			 </tr>
			 <br>
			 <tr>
			   <td >Password </td>
			   <td><input name="password" type="password" id="password"></td>
			 </tr>
			 
			  <tr>
			  <td></td>
			   <td>  <input class="btn-primary" style="width:150px;height: 30px;font-size: 20px"  type="submit" id="loginsubmit" value="Login">
			   </td>
			 </tr>
       </table>
	   </form>
	   <br><br>
	   <p>New User ? <a href="register.php">Signup</a> Free</p>
	   <span class="empty" style="display: none;">Field must not be empty !</span>
	   <span class="error" style="display: none;">Email or Password not matched !</span>
	   <span class="disable" style="display: none;">User Id disabled !</span>
	</div>


	
</div>
<?php include 'inc/footer.php'; ?>