 </section>
<section class="footeroption">
		<h2 style="color: red"; ><?php echo "Time remaining:1 hr 29 minutes"; ?></h2>
	</section>
</div>
</body>
</html>