 </section>
<section class="footeroption">
		<h2 style="font-size: 30px;color: red"; >  <?php echo "Time: 09:45:24"; ?></h2>
	</section>
</div>
</body>
</html>