<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();
$question = $exm->getQuestion();
$total = $exm->getTotalRows();
?>
<div class="main">
<h1 style="color: black;">Welcome to Online Exam</h1>
	<div class="starttest">
		<strong><h2>Economics Paper 1</h2></strong>
		<p>Year End Exams</p>

		<ul>
			
			<li><strong>Number of Questions:</strong> <?php echo $total; ?></li>
			<li><strong>Question Type:</strong> Multiple Choice</li>
		</ul>

		<a href="test.php?q=<?php echo $question['quesNo']; ?>">Start Exam</a>

	</div>

  </div>
<?php include 'inc/footer2.php'; ?>