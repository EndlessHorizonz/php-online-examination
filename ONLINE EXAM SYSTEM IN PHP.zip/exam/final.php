<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();
?>
<div class="main">
<h1>You are done!</h1>

<div class="starttest">
	<p>You have just competed the exam.</p>
	<p>Final Score: 

		<?php 
		if (isset($_SESSION['score'])) {
			echo $_SESSION['score'];
			unset($_SESSION['score']);
		}
		 ?>

	</p>

	<a href="viewans.php">View Answers</a>
	<a href="starttest.php"></a>
</div>
	
  </div>
<?php include 'inc/footer.php'; ?>